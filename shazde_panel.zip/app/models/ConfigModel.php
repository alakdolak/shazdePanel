<?php

namespace App\models;

use Illuminate\Database\Eloquent\Model;

class ConfigModel extends Model {

    protected $table = 'config';
    public $timestamps = false;
}
