<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .col-xs-12 {
            margin-top: 20px;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>افزودن محتوا</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <form method="post" action="<?php echo e(route('doUploadMainContent')); ?>" enctype="multipart/form-data" style="direction: rtl">

                    <?php echo e(csrf_field()); ?>


                    <center class="row">

                        <div class="col-xs-12">
                            <div class="btn-group images-cropper-pro">
                                <label for="kindPlaceId">مکان مورد نظر</label>
                                <select name="kindPlaceId" id="kindPlaceId">
                                    <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php if($kindPlaceId == $place->id): ?>
                                            <option selected value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                        <?php else: ?>
                                            <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                        <?php endif; ?>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                        <div class="col-xs-12">
                            <div class="btn-group images-cropper-pro">
                                <label for="inputImage" class="btn btn-primary img-cropper-cp">
                                    <input type="file" accept="application/vnd.ms-excel" name="content" id="inputImage" class="hide"> آپلود فایل اکسل محتوا
                                </label>
                                <p id="fileName_content"></p>
                            </div>
                        </div>

                        <div class="col-xs-12">
                            <div class="btn-group images-cropper-pro">
                                <label for="inputImage2" class="btn btn-primary img-cropper-cp">
                                    <input type="file" accept="application/zip" name="photos" id="inputImage2" class="hide"> آپلود فایل زیپ تصاویر
                                </label>
                                <p id="fileName_photos"></p>
                            </div>
                        </div>

                        <div class="col-xs-12">
                            <input class="btn btn-success" type="submit" value="تایید و ارسال">
                            <p style="margin-top: 10px"><?php echo html_entity_decode($msg); ?></p>
                        </div>
                    </center>
                </form>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>

    <script>

        $(document).ready(function(){
            $('input[type="file"]').change(function(e){
                var fileName = e.target.files[0].name;
                $("#fileName_" + this.name).empty().append(fileName);
            });
        });

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/uploadMainContent.blade.php ENDPATH**/ ?>