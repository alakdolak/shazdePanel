<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .col-xs-6 {
            float: right;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>پست های منتخب</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="col-xs-12">

                    <?php if(count($posts) == 0): ?>
                        <p>پستی موجود نیست</p>
                    <?php else: ?>
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div id="post_<?php echo e($post->id); ?>" class="col-xs-6" style="padding: 10px">
                                <p><?php echo e($post->title); ?></p>
                                <img onmouseenter="" style="width: 80%" src="<?php echo e(URL::asset('posts/' . $post->pic)); ?>">
                                <div id="addToFavorite_<?php echo e($post->id); ?>" class="col-xs-12 <?php echo e(($post->favorited) ? 'hidden' : ''); ?>" style="margin-top: 10px">
                                    <button onclick="addToFavoritePosts('<?php echo e($post->id); ?>')" class="btn btn-success">انتخاب به عنوان پست منتخب</button>
                                </div>
                                <div id="deleteFromFavorite_<?php echo e($post->id); ?>" class="col-xs-12 <?php echo e((!$post->favorited) ? 'hidden' : ''); ?>" style="margin-top: 10px">
                                    <button onclick="deleteFromFavoritePosts('<?php echo e($post->id); ?>')" class="btn btn-warning">حذف از پست منتخب</button>
                                </div>

                                <div id="addToBanner_<?php echo e($post->id); ?>" class="col-xs-12 <?php echo e(($post->bannered ? 'hidden' : '')); ?>" style="margin-top: 10px">
                                    <button onclick="addToBannerPosts('<?php echo e($post->id); ?>')" class="btn btn-success">انتخاب به عنوان پست بنر</button>
                                </div>

                                <div id="deleteFromBanner_<?php echo e($post->id); ?>" class="col-xs-12 <?php echo e((!$post->bannered ? 'hidden' : '')); ?>" style="margin-top: 10px">
                                    <button onclick="deleteFromBannerPosts('<?php echo e($post->id); ?>')" class="btn btn-danger">حذف از پست بنر</button>
                                </div>

                                <div class="col-xs-12" style="margin-top: 10px">
                                    <button onclick="document.location.href = '<?php echo e(route('editPost', ['id' => $post->id])); ?>'" class="btn btn-primary">ویرایش پست</button>
                                </div>
                                <div class="col-xs-12" style="margin-top: 10px">
                                    <button onclick="deletePost('<?php echo e($post->id); ?>')" class="btn btn-danger">حذف پست</button>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>

                </center>

                <center class="col-xs-12">
                    <button onclick="document.location.href = '<?php echo e(route('createPost')); ?>'" class="btn btn-primary">افزودن پست جدید</button>
                    <button class="btn btn-primary">افزودن دسته ای پست</button>
                </center>

            </div>
        </div>

    </div>

    <div class="col-md-2"></div>

    <script>

        function deletePost(postId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('deletePost')); ?>',
                data: {
                    'postId': postId
                },
                success: function (res) {
                    if(res == "ok")
                        $("#post_" + postId).remove();

                }
            });
        }

        function deleteFromFavoritePosts(postId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('deleteFromFavoritePosts')); ?>',
                data: {
                    'postId': postId
                },
                success: function (res) {
                    if(res == "ok") {
                        $("#deleteFromFavorite_" + postId).addClass('hidden');
                        $("#addToFavorite_" + postId).removeClass('hidden');
                    }

                }
            });
        }

        function deleteFromBannerPosts(postId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('deleteFromBannerPosts')); ?>',
                data: {
                    'postId': postId
                },
                success: function (res) {
                    if(res == "ok") {
                        $("#deleteFromBanner_" + postId).addClass('hidden');
                        $("#addToBanner_" + postId).removeClass('hidden');
                    }

                }
            });
        }

        function addToBannerPosts(postId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('addToBannerPosts')); ?>',
                data: {
                    'postId': postId
                },
                success: function (res) {
                    if(res == "ok") {
                        $("#deleteFromBanner_" + postId).removeClass('hidden');
                        $("#addToBanner_" + postId).addClass('hidden');
                    }

                }
            });

        }

        function addToFavoritePosts(postId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('addToFavoritePosts')); ?>',
                data: {
                    'postId': postId
                },
                success: function (res) {
                    if(res == "ok"){
                        $("#deleteFromFavorite_" + postId).removeClass('hidden');
                        $("#addToFavorite_" + postId).addClass('hidden');
                    }

                }
            });

        }
        
    </script>
    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/post/posts.blade.php ENDPATH**/ ?>