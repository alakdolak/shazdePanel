<!doctype html>
<html class="no-js" lang="en">

<head>

    <?php $__env->startSection('header'); ?>
        <meta charset="utf-8">
        <meta http-equiv="x-ua-compatible" content="ie=edge">
        <title>پنل شازده</title>
        <meta name="description" content="">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <!-- favicon
            ============================================ -->
        <link rel="shortcut icon" type="image/x-icon" href="<?php echo e(URL::asset('img/favicon.png')); ?>">
        <!-- Google Fonts
            ============================================ -->
        <link href="https://fonts.googleapis.com/css?family=Open+Sans:300,300i,400,400i,700,700i,800" rel="stylesheet">
        <!-- Bootstrap CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/bootstrap.min.css')); ?>">
        <!-- Bootstrap CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/font-awesome.min.css')); ?>">

        <!-- adminpro icon CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/adminpro-custon-icon.css')); ?>">

        <!-- meanmenu icon CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/meanmenu.min.css')); ?>">

        <!-- mCustomScrollbar CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/jquery.mCustomScrollbar.min.css')); ?>">

        <!-- animate CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/animate.css')); ?>">

        <!-- jvectormap CSS
            ============================================ -->


        <!-- normalize CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/data-table/bootstrap-table.css')); ?>">
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/data-table/bootstrap-editable.css')); ?>">

        <!-- normalize CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/normalize.css')); ?>">
        <!-- charts CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/c3.min.css')); ?>">
        <!-- style CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/style.css')); ?>">
        <!-- responsive CSS
            ============================================ -->
        <link rel="stylesheet" href="<?php echo e(URL::asset('css/responsive.css')); ?>">

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>" />
        <!-- modernizr JS
            ============================================ -->
        <script src="<?php echo e(URL::asset('js/vendor/modernizr-2.8.3.min.js')); ?>"></script>
        <script src="<?php echo e(URL::asset('js/jquery.min.js')); ?>"></script>

        <style>
            .dropdown-item {
                text-align: right;
            }

            .main-sparkline8-hd {
                direction: rtl;
            }

            .hidden {
                display: none !important;
            }

            .calendar > table {
                width: 100%;
            }

        </style>

        <script>
            function validateNumber(evt) {
                var theEvent = evt || window.event;

                // Handle paste
                if (theEvent.type === 'paste') {
                    key = event.clipboardData.getData('text/plain');
                } else {
                    // Handle key press
                    var key = theEvent.keyCode || theEvent.which;
                    key = String.fromCharCode(key);
                }
                var regex = /[0-9]|\./;
                if( !regex.test(key) ) {
                    theEvent.returnValue = false;
                    if(theEvent.preventDefault) theEvent.preventDefault();
                }
            }
        </script>

    <?php echo $__env->yieldSection(); ?>

</head>

<body class="materialdesign">

    <!--[if lt IE 8]>
    <p class="browserupgrade">You are using an <strong>outdated</strong> browser. Please <a href="http://browsehappy.com/">upgrade your browser</a> to improve your experience.</p>
    <![endif]-->
    <!-- Header top area start-->
    <div class="wrapper-pro">
        <div class="left-sidebar-pro">
            <nav id="sidebar">
                <div class="sidebar-header">
                    <h3>پنل شازده مسافر</h3>
                </div>
                <div class="left-custom-menu-adp-wrap">
                    <ul class="nav navbar-nav left-sidebar-menu-pro">
                        <?php if(\Illuminate\Support\Facades\Auth::check()): ?>
                            <li>
                                <a href="<?php echo e(route('home')); ?>" aria-expanded="false"><i class="fa big-icon fa-home"></i> <span class="mini-dn">خانه</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-envelope"></i> <span class="mini-dn">مدیریت محتوا</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('choosePlace', ['mode' => 'alt'])); ?>" class="dropdown-item">تصاویر و alt آنها</a>
                                    <a href="<?php echo e(route('chooseCity', ['mode' => 'seo'])); ?>" class="dropdown-item">تگ ها و متا صفحات</a>
                                    <a href="<?php echo e(route('manageNoFollow')); ?>" class="dropdown-item">مدیریت لینک ها</a>
                                    <a href="<?php echo e(route('chooseCity', ['mode' => 'content'])); ?>" class="dropdown-item">تغییر محتوای صفحات</a>
                                    <a href="<?php echo e(route('lastActivities')); ?>" class="dropdown-item">فعالیت های اخیر</a>
                                    <a href="<?php echo e(route('posts')); ?>" class="dropdown-item">مدیریت پست ها</a>
                                    <a href="<?php echo e(route('uploadMainContent')); ?>" class="dropdown-item">افزودن محتوا</a>
                                    <a href="<?php echo e(route('seoTester')); ?>" class="dropdown-item">تست  سئو صفحات</a>
                                </div>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-flask"></i> <span class="mini-dn">مدال ها</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('levels')); ?>" class="dropdown-item">تعیین سطوح</a>
                                    <a href="<?php echo e(route('medals')); ?>" class="dropdown-item">تعیین مدال ها</a>
                                </div>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-pie-chart"></i> <span class="mini-dn">تنظیمات سیستمی</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('determineRadius')); ?>" class="dropdown-item">تعیین شعاع مکان های نزدیک</a>
                                    <a href="<?php echo e(route('ages')); ?>" class="dropdown-item">مدیریت سنین</a>
                                    <a href="<?php echo e(route('backup')); ?>" class="dropdown-item">مدیریت پشتیبانی</a>
                                    <a href="<?php echo e(route('offers')); ?>" class="dropdown-item">مدیریت کد های تخفیف</a>
                                    <a href="project-details.html" class="dropdown-item">Project Details</a>
                                </div>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-bar-chart-o"></i> <span class="mini-dn">مدیریت کاربران</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown chart-left-menu-std animated flipInX">
                                    <a href="<?php echo e(route('users')); ?>" class="dropdown-item">کاربران</a>
                                    <a href="<?php echo e(route('register')); ?>" class="dropdown-item">افزودن ادمین جدید</a>
                                    <a href="area-charts.html" class="dropdown-item">Area Charts</a>
                                    <a href="rounded-chart.html" class="dropdown-item">Rounded Charts</a>
                                    <a href="c3.html" class="dropdown-item">C3 Charts</a>
                                    <a href="sparkline.html" class="dropdown-item">Sparkline Charts</a>
                                    <a href="peity.html" class="dropdown-item">Peity Charts</a>
                                </div>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">مدیریت تبلیغات</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('company')); ?>" class="dropdown-item">شرکت های تبلیغاتی</a>
                                    <a href="<?php echo e(route('section')); ?>" class="dropdown-item">قسمت های تبلیغاتی</a>
                                    <a href="<?php echo e(route('seeAds')); ?>" class="dropdown-item">تبلیغات</a>
                                </div>
                            </li>
                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">گزارشات</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('systemLastActivities')); ?>" class="dropdown-item">آخرین فعالیت های سیستمی</a>
                                </div>
                            </li>

                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">پیام رسانی</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('sendMsg')); ?>" class="dropdown-item">ارسال پیام</a>
                                    <a href="<?php echo e(route('msgs')); ?>" class="dropdown-item">پیام های ارسال شده</a>
                                </div>
                            </li>

                            <li class="nav-item"><a href="#" data-toggle="dropdown" role="button" aria-expanded="false" class="nav-link dropdown-toggle"><i class="fa big-icon fa-table"></i> <span class="mini-dn">پروفایل کاربری</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                                <div role="menu" class="dropdown-menu left-menu-dropdown animated flipInX">
                                    <a href="<?php echo e(route('changePass')); ?>" class="dropdown-item">تغییر رمزعبور</a>
                                    <a href="<?php echo e(route('logout')); ?>" class="dropdown-item">خروج</a>
                                </div>
                            </li>
                        <?php else: ?>
                            <li>
                                <a href="<?php echo e(route('login')); ?>" aria-expanded="false"><i class="fa big-icon fa-login"></i> <span class="mini-dn">ورود</span> <span class="indicator-right-menu mini-dn"><i class="fa indicator-mn fa-angle-left"></i></span></a>
                            </li>
                        <?php endif; ?>
                    </ul>
                </div>
            </nav>
        </div>

        <div class="content-inner-all">
            <?php echo $__env->yieldContent('content'); ?>
        </div>


        <?php $__env->startSection('reminder'); ?>
        <!-- jquery
        ============================================ -->
            <script src="<?php echo e(URL::asset('js/vendor/jquery-1.11.3.min.js')); ?>"></script>
            <!-- bootstrap JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/bootstrap.min.js')); ?>"></script>
            <!-- meanmenu JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/jquery.meanmenu.js')); ?>"></script>
            <!-- mCustomScrollbar JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/jquery.mCustomScrollbar.concat.min.js')); ?>"></script>
            <!-- sticky JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/jquery.sticky.js')); ?>"></script>
            <!-- scrollUp JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/jquery.scrollUp.min.js')); ?>"></script>
            <!-- scrollUp JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/wow/wow.min.js')); ?>"></script>
            <!-- counterup JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/counterup/jquery.counterup.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/counterup/waypoints.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/counterup/counterup-active.js')); ?>"></script>
            <!-- jvectormap JS
                ============================================ -->
            
            
            
            <!-- peity JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/peity/jquery.peity.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/peity/peity-active.js')); ?>"></script>
            <!-- sparkline JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/sparkline/jquery.sparkline.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/sparkline/sparkline-active.js')); ?>"></script>
            <!-- flot JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/flot/Chart.min.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/flot/dashtwo-flot-active.js')); ?>"></script>
            <!-- data table JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/data-table/bootstrap-table.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/tableExport.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/data-table-active.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/bootstrap-table-editable.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/bootstrap-editable.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/bootstrap-table-resizable.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/colResizable-1.5.source.js')); ?>"></script>
            <script src="<?php echo e(URL::asset('js/data-table/bootstrap-table-export.js')); ?>"></script>
            <!-- main JS
                ============================================ -->
            <script src="<?php echo e(URL::asset('js/main.js')); ?>"></script>

            <script type="text/javascript">
                $.ajaxSetup({
                    headers: {
                        'X-CSRF-TOKEN': $('meta[name="csrf-token"]').attr('content')
                    }
                });
            </script>
        <?php echo $__env->yieldSection(); ?>
    </div>
</body><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/layouts/structure.blade.php ENDPATH**/ ?>