<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }
        td {
            min-width: 80px;
            padding: 8px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت بخش های تبلیغاتی</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">

                    <form method="post" action="<?php echo e(route('addPageToSection', ['sectionId' => $section->id])); ?>">
                        <?php echo e(csrf_field()); ?>

                        <center class="col-xs-12">

                            <div class="col-xs-12">
                                <label for="main_page">main_page</label>
                                <input id="main_page" <?php echo e((in_array(getValueInfo('main_page'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('main_page')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="hotel-detail">hotel-detail</label>
                                <input id="hotel-detail" <?php echo e((in_array(getValueInfo('hotel-detail'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('hotel-detail')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="adab-detail">adab-detail</label>
                                <input id="adab-detail" <?php echo e((in_array(getValueInfo('adab-detail'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('adab-detail')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="amaken-detail">amaken-detail</label>
                                <input id="amaken-detail" <?php echo e((in_array(getValueInfo('amaken-detail'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('amaken-detail')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="majara-detail">majara-detail</label>
                                <input id="majara-detail" <?php echo e((in_array(getValueInfo('majara-detail'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('majara-detail')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="restaurant-detail">restaurant-detail</label>
                                <input id="restaurant-detail" <?php echo e((in_array(getValueInfo('restaurant-detail'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('restaurant-detail')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="hotel-list">hotel-list</label>
                                <input id="hotel-list" <?php echo e((in_array(getValueInfo('hotel-list'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('hotel-list')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="majara-list">majara-list</label>
                                <input id="majara-list" <?php echo e((in_array(getValueInfo('majara-list'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('majara-list')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="restaurant-list">restaurant-list</label>
                                <input id="restaurant-list" <?php echo e((in_array(getValueInfo('restaurant-list'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('restaurant-list')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="amaken-list">amaken-list</label>
                                <input id="amaken-list" <?php echo e((in_array(getValueInfo('amaken-list'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('amaken-list')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <label for="adab-list">adab-list</label>
                                <input id="adab-list" <?php echo e((in_array(getValueInfo('adab-list'), $pages)) ? 'checked' : ''); ?> name="page[]" value='<?php echo e(getValueInfo('adab-list')); ?>' type="checkbox">
                            </div>

                            <div class="col-xs-12">
                                <input type="submit" class="btn btn-primary" value="تایید">
                            </div>

                        </center>
                    </form>

                </center>
            </div>
        </div>
    </div>

    <div class="col-md-1"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/publicity/sectionStep2.blade.php ENDPATH**/ ?>