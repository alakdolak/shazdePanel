<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>بررسی سئو صفحه</h1>
                </div>
            </div>

            <form method="post" action="<?php echo e(route('doSeoTest')); ?>">

                <?php echo e(csrf_field()); ?>


                <div style="direction: rtl; height: auto !important;" class="sparkline8-graph dashone-comment  dashtwo-messages">
                    <center class="row">
                        <label for="url">آدرس مد نظر</label>
                        <input name="url" id="url" type="text">
                        <center style="margin-top: 10px">
                            <input class="btn btn-success" type="submit" value="تایید">
                        </center>
                    </center>

                </div>
            </form>
        </div>
    </div>

    <div class="col-md-1"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/seoTester/seoTester.blade.php ENDPATH**/ ?>