<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت سنین</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">
                    <?php if(count($ages) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">سنی وجود ندارد</h4>
                        </div>
                    <?php else: ?>
                        <form method="post" action="<?php echo e(route('opOnAge')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php $__currentLoopData = $ages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $age): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xs-12">
                                    <span>
                                        <?php echo e($age->name); ?>

                                    </span>
                                    <button name="ageId" value="<?php echo e($age->id); ?>" class="sparkline9-collapse-close transparentBtn" data-toggle="tooltip" title="حذف سن" style="width: auto">
                                        <span ><i class="fa fa-times"></i></span>
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </form>
                    <?php endif; ?>

                    <?php if($mode == "see"): ?>
                        <div class="col-xs-12">
                            <a href="<?php echo e(route('addAge')); ?>">
                                <button class=" btn btn-default transparentBtn" style="width: auto" data-toggle="tooltip" title="اضافه کردن سن جدید">
                                    <span class="glyphicon glyphicon-plus"></span>
                                </button>
                            </a>
                        </div>
                    <?php elseif($mode == "add"): ?>
                        <form method="post" action="<?php echo e(route('addAge')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-xs-12">
                                <label>
                                    <span>نام سن</span>
                                    <input type="text" name="ageName" maxlength="40" required autofocus>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <p class="warning_color"><?php echo e($msg); ?></p>
                                <input type="submit" name="addAge" value="اضافه کن" class="btn btn-primary" style="width: auto; margin-top: 10px">
                            </div>
                        </form>
                    <?php endif; ?>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/ages.blade.php ENDPATH**/ ?>