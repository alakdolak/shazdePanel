<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        label {
            min-width: 150px;
        }

        input, select {
            width: 200px;
        }

        .row {
            direction: rtl;
        }

        #result {
            max-height: 300px;
            overflow: auto;
            margin-top: 20px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>ویرایش محتوا</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">
                    <div class="col-xs-12">
                        <label>
                            <span>دسته مورد نظر</span>
                            <select id="kindPlaceId">
                                <?php $__currentLoopData = $places; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $place): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($place->id); ?>"><?php echo e($place->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </label>
                    </div>

                    <div class="col-xs-12">
                        <label>
                            <span>مکان مورد نظر</span>
                            <input type="text" onkeyup="search(event)" id="placeName">
                        </label>
                        <div id="result"></div>
                    </div>

                    <div class="col-xs-12">
                        <input type="submit" value="تایید" class="btn btn-primary" name="saveChange">
                    </div>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>

    <script>

        var currIdx = 0, suggestions = [];
        var searchDir = '<?php echo e(route('totalSearch')); ?>';

        function redirect(id) {
            document.location.href = '<?php echo e($url); ?>' + id + "/" + $("#kindPlaceId").val()
        }

        function search(e) {

            var val = $("#placeName").val();
            $(".suggest").css("background-color", "transparent").css("padding", "0").css("border-radius", "0");

            if (null == val || "" == val || val.length < 2)
                $("#result").empty();
            else {

                if (13 == e.keyCode && -1 != currIdx) {
                    return redirect(suggestions[currIdx].id);
                }

                if (13 == e.keyCode && -1 == currIdx && suggestions.length > 0) {
                    return redirect(suggestions[0].id);
                }

                if (40 == e.keyCode) {
                    if (currIdx + 1 < suggestions.length) {
                        currIdx++;
                    }
                    else {
                        currIdx = 0;
                    }

                    if (currIdx >= 0 && currIdx < suggestions.length)
                        $("#suggest_" + currIdx).css("background-color", "#dcdcdc").css("padding", "10px").css("border-radius", "5px");

                    return;
                }
                if (38 == e.keyCode) {
                    if (currIdx - 1 >= 0) {
                        currIdx--;
                    }
                    else
                        currIdx = suggestions.length - 1;

                    if (currIdx >= 0 && currIdx < suggestions.length)
                        $("#suggest_" + currIdx).css("background-color", "#dcdcdc").css("padding", "10px").css("border-radius", "5px");
                    return;
                }

                if ("ا" == val[0]) {

                    for (var val2 = "آ", i = 1; i < val.length; i++) val2 += val[i];

                    $.ajax({
                        type: "post",
                        url: searchDir,
                        data: {
                            kindPlaceId: $('#kindPlaceId').val(),
                            key: val,
                            key2: val2
                        },
                        success: function (response) {

                            var newElement = "";

                            if (response.length == 0) {
                                newElement = "موردی یافت نشد";
                                return;
                            }

                            response = JSON.parse(response);
                            currIdx = -1;
                            suggestions = response;

                            for (i = 0; i < response.length; i++) {
                                if(response[i].cityName !== undefined)
                                    newElement += "<p style='cursor: pointer' class='suggest' id='suggest_" + i + "' onclick='redirect(" + response[i].id + ")'>" + response[i].targetName + " در " + response[i].cityName + " در " + response[i].stateName + "</p>";
                                else
                                    newElement += "<p style='cursor: pointer' class='suggest' id='suggest_" + i + "' onclick='redirect(" + response[i].id + ")'>" + response[i].targetName + " در " + response[i].stateName + "</p>";
                            }

                            $("#result").empty().append(newElement)
                        }
                    })
                }

                else $.ajax({
                    type: "post",
                    url: searchDir,
                    data: {
                        kindPlaceId: $("#kindPlaceId").val(),
                        key: val
                    },
                    success: function (response) {

                        var newElement = "";

                        if (response.length == 0) {
                            newElement = "موردی یافت نشد";
                            return;
                        }

                        response = JSON.parse(response);
                        currIdx = -1;
                        suggestions = response;

                        for (i = 0; i < response.length; i++) {
                            if(response[i].cityName !== undefined)
                                newElement += "<p style='cursor: pointer' class='suggest' id='suggest_" + i + "' onclick='redirect(" + response[i].id + ")'>" + response[i].targetName + " در " + response[i].cityName + " در " + response[i].stateName + "</p>";
                            else
                                newElement += "<p style='cursor: pointer' class='suggest' id='suggest_" + i + "' onclick='redirect(" + response[i].id + ")'>" + response[i].targetName + " در " + response[i].stateName + "</p>";
                        }

                        $("#result").empty().append(newElement)
                    }
                })
            }
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/choosePlace.blade.php ENDPATH**/ ?>