<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        th, td {
            min-width: 100px;
            text-align: right;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>افزودن پست جدید</h1>
                </div>

                <form method="post" action="<?php echo e(route('setPostPic', ['id' => $id])); ?>" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>


                    <center>
                        <h3>تصویر اصلی پست خود را مشخص کنید</h3>

                        <?php if($pic != null): ?>
                            <p>تصویر انتخاب شده</p>
                            <img src="<?php echo e(\Illuminate\Support\Facades\URL::asset('posts/' . $pic)); ?>">

                            <div style="padding: 5px; margin: 10px; border: 1px dashed">
                                <p>تغییر تصویر</p>
                                <input name="pic" type="file" accept="image/*">
                            </div>

                        <?php else: ?>
                            <input name="pic" type="file" accept="image/*">
                        <?php endif; ?>

                    </center>

                <center style="padding: 10px">
                    <input type="submit" value="مرحله بعد" class="btn btn-success">
                </center>

                </form>

            </div>

        </div>
    </div>

    <div class="col-md-1"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/post/createPostStep3.blade.php ENDPATH**/ ?>