<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>نتایج بررسی</h1>
                </div>
            </div>

            <div style="height: auto !important;" class="sparkline8-graph dashone-comment  dashtwo-messages">
                <center class="row">
                    <?php $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12" style="margin-top: 20px">
                            <h1><?php echo e($key); ?></h1>
                            <table class="table table-bordered table-adminpro">
                                <thead>
                                <tr>
                                    <th class="code-adminpro-center">key</th>
                                    <th>value</th>
                                </tr>
                                </thead>

                                <?php if($key == "wordDensity"): ?>
                                    <tr>
                                        <td>
                                            تعداد کل کلمات
                                        </td>
                                        <td><?php echo e($totalWord); ?></td>
                                    </tr>
                                <?php endif; ?>

                                <tbody>
                                    <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key2 => $value2): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <?php if(is_array($value2)): ?>
                                            <tr>
                                                <td>
                                                    <center>
                                                        <?php echo e($key2); ?>

                                                    </center>
                                                </td>
                                                <td></td>
                                            </tr>

                                            <?php $__currentLoopData = $value2; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key3 => $value3): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                <?php if(is_array($value3)): ?>
                                                    <tr>
                                                        <td>
                                                            <center>
                                                                <?php echo e($key3); ?>

                                                            </center>
                                                        </td>
                                                        <td></td>
                                                    </tr>

                                                    <?php $__currentLoopData = $value3; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key4 => $value4): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                                        <?php if(is_array($value4)): ?>

                                                        <?php else: ?>
                                                            <tr>
                                                                <td><?php echo e($key4); ?></td>
                                                                <td><?php echo e($value4); ?></td>
                                                            </tr>
                                                        <?php endif; ?>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                                <?php else: ?>
                                                    <?php if($key3 != 'html'): ?>
                                                        <tr>
                                                            <td><?php echo e($key3); ?></td>
                                                            <td><?php echo e($value3); ?></td>
                                                        </tr>
                                                    <?php endif; ?>
                                                <?php endif; ?>

                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        <?php else: ?>
                                            <tr>
                                                <td><?php echo e($key2); ?></td>
                                                <td><?php echo e(($key == "wordDensity") ? $value2 . '  -  ' . round($value2 * 100 / $totalWord, 2) . '%': $value2); ?></td>
                                            </tr>
                                        <?php endif; ?>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>

                        </div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-1"></div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/seoTester/seoTesterResult.blade.php ENDPATH**/ ?>