<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }
        td {
            min-width: 80px;
            padding: 8px;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت بخش های تبلیغاتی</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">

                    <?php if(count($section) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">بخشی وجود ندارد</h4>
                        </div>
                    <?php else: ?>
                        <form method="post" action="<?php echo e(route('deleteSection')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <center class="col-xs-12">
                                <table style="max-width: 100%; overflow-x: auto; display: block">
                                    <tr>
                                        <td>نام بخش</td>
                                        <td>top</td>
                                        <td>left</td>
                                        <td>right</td>
                                        <td>bottom</td>
                                        <td>عرض</td>
                                        <td>ارتفاع</td>
                                        <td>background-size</td>
                                        <td>نمایش در حالت گوشی</td>
                                        <td>mobile top</td>
                                        <td>mobile left</td>
                                        <td>mobile right</td>
                                        <td>mobile bottom</td>
                                        <td>عملیات</td>
                                    </tr>
                                    <?php $__currentLoopData = $section; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td>
                                                <?php echo e($itr->name); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->top_); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->left_); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->right_); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->bottom_); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->width); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->height); ?>

                                            </td>

                                            <td>
                                                <?php echo e(($itr->backgroundSize) ? 'contain' : 'cover'); ?>

                                            </td>

                                            <td>
                                                <?php echo e(($itr->mobileHidden == 1) ? 'بله' : 'خیر'); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->mobileTop); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->mobileLeft); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->mobileRight); ?>

                                            </td>

                                            <td>
                                                <?php echo e($itr->mobileBottom); ?>

                                            </td>

                                            <td>
                                                <button name="deleteSection" value="<?php echo e($itr->id); ?>" class="sparkline9-collapse-close transparentBtn" data-toggle="tooltip" title="حذف سطح" style="width: auto">
                                                    <span ><i class="fa fa-times"></i></span>
                                                </button>

                                                <button type="button" name="editSection" onclick="document.location.href = '<?php echo e(route('editSection', ['id' => $itr->id])); ?>'" class="sparkline9-collapse-close transparentBtn" data-toggle="tooltip" title="ویرایش" style="width: auto">
                                                    <span ><i class="fa fa-wrench"></i></span>
                                                </button>
                                            </td>
                                        </tr>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </table>
                            </center>
                        </form>
                    <?php endif; ?>

                    <div class="col-xs-12">
                        <button id="addBtn" onclick="createSection()" class="btn btn-default transparentBtn" style="width: auto" data-toggle="modal" data-target="#InformationproModalalert">
                            <span class="glyphicon glyphicon-plus"></span>
                        </button>
                    </div>

                </center>
            </div>
        </div>
    </div>

    <div class="col-md-1"></div>

    <script>

        function createSection() {
            createModal('<?php echo e(route('section')); ?>',
                    [{'name': 'name', 'class': [], 'type': 'text', 'label': 'نام قسمت', 'value': ''},
                        {'name': 'top', 'class': [], 'type': 'text', 'label': 'top', 'value': ''},
                        {'name': 'left', 'class': [], 'type': 'text', 'label': 'left', 'value': ''},
                        {'name': 'right', 'class': [], 'type': 'text', 'label': 'right', 'value': ''},
                        {'name': 'bottom', 'class': [], 'type': 'text', 'label': 'bottom', 'value': ''},
                        {'name': 'width', 'class': [], 'type': 'text', 'label': 'عرض', 'value': ''},
                        {'name': 'height', 'class': [], 'type': 'text', 'label': 'ارتفاع', 'value': ''},
                        {'name': 'mobileHidden', 'class': [], 'type': 'select',  'label': 'نمایش در حالت گوشی', 'options': JSON.stringify([
                            {'id': 1, 'name': 'ندارد'},
                            {'id': 0, 'name': 'دارد'}
                        ]), 'value': ''},
                        {'name': 'backgroundSize', 'class': [], 'type': 'select',  'label': 'background-size', 'options': JSON.stringify([
                            {'id': 1, 'name': 'contain'},
                            {'id': 0, 'name': 'cover'}
                        ]), 'value': ''},
                        {'name': 'mobileTop', 'class': [], 'type': 'text', 'label': 'mobile top', 'value': ''},
                        {'name': 'mobileLeft', 'class': [], 'type': 'text', 'label': 'mobile left', 'value': ''},
                        {'name': 'mobileRight', 'class': [], 'type': 'text', 'label': 'mobile right', 'value': ''},
                        {'name': 'mobileBottom', 'class': [], 'type': 'text', 'label': 'mobile bottom', 'value': ''}],
                    'افزودن قسمت جدید'
                    , '<?php echo e((isset($msg) ? $msg : '')); ?>');
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/publicity/editSection.blade.php ENDPATH**/ ?>