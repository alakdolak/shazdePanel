<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .clockpicker-button {
            font-family: IRANSans !important;
        }

    </style>

    <script src = <?php echo e(URL::asset("js/calendar.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/calendar-setup.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/calendar-fa.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/jalali.js")); ?>></script>
    <script src="<?php echo e(URL::asset('js/jquery.timepicker.min.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/clockpicker.css')); ?>">
    <script src="<?php echo e(URL::asset('js/clockpicker.js')); ?>"></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/standalone.css')); ?>">
    <link rel="stylesheet" href = <?php echo e(URL::asset("css/calendar-green.css")); ?>>

    <link rel="stylesheet" type="text/css" href="<?php echo e(URL::asset('dist/bootstrap-clockpicker.min.css')); ?>">
    <script type="text/javascript" src="<?php echo e(URL::asset('dist/bootstrap-clockpicker.min.js')); ?>"></script>

    <style>
        .clockpicker-popover {
            z-index: 100000;
            direction: ltr;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>افزودن پست جدید</h1>
                </div>

                <form method="post" action="<?php echo e(route('setPostInterval', ['id' => $id])); ?>" enctype="multipart/form-data">

                    <?php echo e(csrf_field()); ?>



                    <center class="row">

                        <h3>زمان نمایش پست خود را مشخص نمایید</h3>

                        <div class="col-xs-12">

                            <center class="col-xs-12" style="margin-top: 10px">

                                <div>
                                    <input type="button"
                                           style="border: none;  width: 15px; height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                           id="date_btn_Start">

                                    <span style="direction: rtl">از تاریخ</span>
                                </div>

                                <input type="text" style="width: 200px" class="form-detail"
                                       name="date" id="date_input_start" readonly>

                                <script>
                                    Calendar.setup({
                                        inputField: "date_input_start",
                                        button: "date_btn_Start",
                                        ifFormat: "%Y/%m/%d",
                                        dateType: "jalali"
                                    });
                                </script>
                            </center>

                            <center class="col-xs-12" style="margin-top: 10px">

                                <div id="timepicker1" style="width: 200px" class="clockpicker">

                                    <label style="display: inline-block">
                                        <span>ساعت شروع</span>
                                    </label>
                                    <div class="clockpicker">
                                        <input type="text" name="time" autocomplete="off" id="sTime" style="direction: ltr" class="form-detail form-control"
                                               value="09:30">
                                    </div>
                                </div>
                            </center>

                        </div>

                    </center>

                <center style="padding: 10px">
                    <input type="submit" value="نهایی سازی پست" class="btn btn-success">
                </center>

                </form>

            </div>

        </div>
    </div>

    <div class="col-md-1"></div>

    <script type="text/javascript">


        $('input.timepicker').timepicker({
            timeFormat: 'hh:mm:ss',
            interval: 5,
            minTime: '00:00',
            maxTime: '11:55',
            defaultTime: '07:00',
            startTime: '00:00',
            dynamic: true,
            dropdown: true,
            scrollbar: true
        });

        $('.clockpicker').clockpicker();

    </script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/post/createPostStep4.blade.php ENDPATH**/ ?>