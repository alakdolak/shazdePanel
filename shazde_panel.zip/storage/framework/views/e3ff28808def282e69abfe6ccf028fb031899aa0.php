<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .col-xs-12 {
            margin: 5px;
        }

        button {
            min-width: 100px;
        }

        td {
            padding: 10px;
            max-width: 300px;
            border: 2px solid black;
        }

        .row {
            direction: rtl;
        }

    </style>

    <script src= <?php echo e(URL::asset("js/calendar.js")); ?>></script>
    <script src= <?php echo e(URL::asset("js/calendar-setup.js")); ?>></script>
    <script src= <?php echo e(URL::asset("js/calendar-fa.js")); ?>></script>
    <script src= <?php echo e(URL::asset("js/jalali.js")); ?>></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/standalone.css')); ?>">
    <link rel="stylesheet" href= <?php echo e(URL::asset("css/calendar-green.css")); ?>>

    <script>
        var selfUrl = '<?php echo e(route('lastActivities')); ?>';
        var deleteLogsDir = '<?php echo e(route('deleteLogs')); ?>';
    </script>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>آخرین پست کاربران</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">
                <center class="row">

                    <div class="col-xs-12">

                        <center class="col-xs-4">
                            <input type="button"
                                   style="border: none; width: 15px;  height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                   id="date_btn_end">
                            <span>تا تاریخ</span>
                            <input type="text" style="max-width: 200px" class="form-detail"
                                   id="date_input_end" onchange="end()" readonly>

                            <script>
                                Calendar.setup({
                                    inputField: "date_input_end",
                                    button: "date_btn_end",
                                    ifFormat: "%Y/%m/%d",
                                    dateType: "jalali"
                                });
                            </script>
                        </center>

                        <center class="col-xs-4">

                            <input type="button"
                                   style="border: none;  width: 15px; height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                   id="date_btn_Start">

                            <span style="direction: rtl">از تاریخ</span>

                            <input type="text" style="max-width: 200px" class="form-detail"
                                   id="date_input_start" onchange="start()" readonly>

                            <script>
                                Calendar.setup({
                                    inputField: "date_input_start",
                                    button: "date_btn_Start",
                                    ifFormat: "%Y/%m/%d",
                                    dateType: "jalali"
                                });
                            </script>
                        </center>

                        <center class="col-xs-4">
                            <label for="confirm">وضعیت تایید</label>
                            <select onchange="redirect(this.value)" id="confirm">
                                <?php if($confirm): ?>
                                    <option value="1">تایید شده ها</option>
                                    <option value="0">تایید نشده ها</option>
                                <?php else: ?>
                                    <option value="0">تایید نشده ها</option>
                                    <option value="1">تایید شده ها</option>
                                <?php endif; ?>
                            </select>
                        </center>

                    </div>

                    <?php $i = 0; $dates = [] ?>

                    <?php if(count($logs) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">فعالیتی وجود ندارد</h4>
                        </div>
                    <?php else: ?>

                        <div class="col-xs-12" style="padding: 20px">

                            <table>
                                <tr>
                                    <td>نام کاربری عامل</td>
                                    <td>پست مورد نظر</td>
                                    <td>تاریخ بارگذاری</td>
                                    <td>توضیحات محتوا</td>
                                    <td>
                                        <p>وضعیت تایید</p>
                                        <p>
                                            <span>انتخاب همه</span><input type="checkbox" data-val="select" onclick="checkAll(this)">
                                        </p>
                                    </td>
                                </tr>

                                <?php $__currentLoopData = $logs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $log): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <?php $dates[$i] = $log->created_at; ?>

                                    <tr id="<?php echo e($i); ?>">
                                        <td><?php echo e($log->username); ?></td>
                                        <td><?php echo e($log->title); ?></td>
                                        <td><?php echo e($log->created_at); ?></td>
                                        <td><?php echo e($log->msg); ?></td>
                                        <td><?php echo e(($log->status) ? "تایید شده" : "تایید نشده ها"); ?></td>
                                        <td>
                                            <input value="<?php echo e($log->id); ?>" type="checkbox" name="checkedLogs[]">
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </table>
                        </div>

                        <button onclick="submitLogs()" class="btn btn-success"><?php echo e((!$confirm) ? 'تایید' : 'رد'); ?></button>
                        <button onclick="deleteLogs()" class="btn btn-danger">حذف</button>
                    <?php endif; ?>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-1"></div>

    <script>

        var exams = <?php echo json_encode($dates); ?>;

        var start_time;
        var examsStartValue = [];
        var examsEndValue = [];
        var stateValue = [];
        var end_time;


        for (var j = 0; j < exams.length; j++) {
            examsEndValue[j] = 1;
            examsStartValue[j] = 1;
            stateValue[j] = 1;
        }

        function start() {
            start_time = document.getElementById('date_input_start').value;
            start_time = start_time.split('/');
            changeStartTime()
        }

        function end() {
            end_time = document.getElementById('date_input_end').value;
            end_time = end_time.split('/');
            changeEndTime();
        }

        function changeStartTime() {

            var day, month, year;

            for (var i = 0; i < exams.length; i++) {

                day = parseInt((exams[i].split('/')[2]));
                month = parseInt((exams[i].split('/')[1]));
                year = parseInt((exams[i].split('/')[0]));

                if (year == start_time[0]) {
                    if (month == start_time[1]) {
                        if (day >= start_time[2]) {
                            examsStartValue[i] = 1;
                        }
                        else {
                            examsStartValue[i] = 0;
                        }
                    }
                    else if (month > start_time[1]) {
                        examsStartValue[i] = 1;
                    }
                    else {
                        examsStartValue[i] = 0;
                    }
                }
                else if (year > start_time[0]) {
                    examsStartValue[i] = 1;
                }
                else {
                    examsStartValue[i] = 0;
                }
            }
            doChange();
        }

        function doChange() {

            for (var i = 0; i < exams.length; i++) {
                if (examsStartValue[i] + examsEndValue[i] + stateValue[i] == 3) {
                    document.getElementById(i).style.display = '';
                }
                else {
                    document.getElementById(i).style.display = 'none';
                }
            }
        }

        function changeEndTime() {

            var day, month, year;

            for (var i = 0; i < exams.length; i++) {

                day = parseInt((exams[i].split('/')[2]));
                month = parseInt((exams[i].split('/')[1]));
                year = parseInt((exams[i].split('/')[0]));

                if (year == end_time[0]) {
                    if (month == end_time[1]) {
                        if (day <= end_time[2]) {
                            examsEndValue[i] = 1;
                        }
                        else {
                            examsEndValue[i] = 0;
                        }
                    }
                    else if (month < end_time[1]) {
                        examsEndValue[i] = 1;
                    }
                    else {
                        examsEndValue[i] = 0;
                    }
                }
                else if (year < end_time[0]) {
                    examsEndValue[i] = 1;
                }
                else {
                    examsEndValue[i] = 0;
                }
            }
            doChange();
        }

        var confirm = '<?php echo e($confirm); ?>';

        function redirect(val) {
            document.location.href = '<?php echo e(route('controlActivityContent', ['activityId' => 'post'])); ?>' + '/' + val;
        }

        function checkAll(val) {

            if($(val).attr('data-val') == 'select') {
                $(":checkbox[name='checkedLogs[]']").prop('checked', true);
                $(val).attr('data-val', 'unSelect');
            }
            else {
                $("input[name='checkedLogs[]']").prop('checked', false);
                $(val).attr('data-val', 'select');
            }

        }
        
        function submitLogs() {

            var checkedValues = $("input:checkbox[name='checkedLogs[]']:checked").map(function() {
                return this.value;
            }).get();

            if(checkedValues.length == 0)
                return;

            $.ajax({
                type: 'post',
                url: (confirm == "1") ? '<?php echo e(route('unSubmitLogs')); ?>' : '<?php echo e(route('submitLogs')); ?>',
                data: {
                    'logs': checkedValues,
                    'activity': 'post'
                },
                success: function (response) {
                    if(response == "ok") {
                        document.location.href = selfUrl;
                    }
                }
            });
        }

        function deleteLogs() {

            var checkedValues = $("input:checkbox[name='checkedLogs[]']:checked").map(function() {
                return this.value;
            }).get();

            if(checkedValues.length == 0)
                return;

            $.ajax({
                type: 'post',
                url: deleteLogsDir,
                data: {
                    'logs': checkedValues
                },
                success: function (response) {
                    if(response == "ok") {
                        document.location.href = selfUrl;
                    }
                }
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/user/controlPostComment.blade.php ENDPATH**/ ?>