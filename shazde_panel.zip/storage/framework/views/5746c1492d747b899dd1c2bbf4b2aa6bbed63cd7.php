<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        th, td {
            min-width: 100px;
            text-align: right;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-1"></div>

    <div class="col-md-10">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>افزودن پست جدید</h1>
                </div>
            </div>

            <div style="height: auto !important;" class="sparkline8-graph dashone-comment  dashtwo-messages">
                <center class="row">

                    <div class="col-xs-12">
                        <div class="datatable-dashv1-list custom-datatable-overright">
                            <table style="direction: rtl" id="table" data-toggle="table" data-key-events="true" data-resizable="true">
                                <thead>
                                    <tr>
                                        <th data-field="temp"  class="hidden" data-editable="false"></th>
                                        <th data-field="tag1" data-editable="true">تگ 1</th>
                                        <th data-field="tag2" data-editable="true">تگ 2</th>
                                        <th data-field="tag3" data-editable="true">تگ 3</th>
                                        <th data-field="tag4" data-editable="true">تگ 4</th>
                                        <th data-field="tag5" data-editable="true">تگ 5</th>
                                        <th data-field="tag6" data-editable="true">تگ 6</th>
                                        <th data-field="tag7" data-editable="true">تگ 7</th>
                                        <th data-field="tag8" data-editable="true">تگ 8</th>
                                        <th data-field="tag9" data-editable="true">تگ 9</th>
                                        <th data-field="tag10" data-editable="true">تگ 10</th>
                                        <th data-field="tag11" data-editable="true">تگ 11</th>
                                        <th data-field="tag12" data-editable="true">تگ 12</th>
                                        <th data-field="tag13" data-editable="true">تگ 13</th>
                                        <th data-field="tag14" data-editable="true">تگ 14</th>
                                        <th data-field="tag15" data-editable="true">تگ 15</th>
                                        <th data-field="h1" data-editable="true">h1</th>
                                        <th data-field="keyword" data-editable="true">keyword</th>
                                        <th data-field="meta" data-editable="true">meta</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr>
                                        <td></td>
                                        <td><?php echo e(($post->tag1)); ?></td>
                                        <td><?php echo e(($post->tag2)); ?></td>
                                        <td><?php echo e(($post->tag3)); ?></td>
                                        <td><?php echo e(($post->tag4)); ?></td>
                                        <td><?php echo e(($post->tag5)); ?></td>
                                        <td><?php echo e(($post->tag6)); ?></td>
                                        <td><?php echo e(($post->tag7)); ?></td>
                                        <td><?php echo e(($post->tag8)); ?></td>
                                        <td><?php echo e(($post->tag9)); ?></td>
                                        <td><?php echo e(($post->tag10)); ?></td>
                                        <td><?php echo e(($post->tag11)); ?></td>
                                        <td><?php echo e(($post->tag12)); ?></td>
                                        <td><?php echo e(($post->tag13)); ?></td>
                                        <td><?php echo e(($post->tag14)); ?></td>
                                        <td><?php echo e(($post->tag15)); ?></td>
                                        <td><?php echo e(($post->h1)); ?></td>
                                        <td><?php echo e(($post->keyword)); ?></td>
                                        <td><?php echo e(($post->meta)); ?></td>
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>

                </center>
            </div>

            <center style="padding: 10px">
                <input type="submit" onclick="document.location.href = '<?php echo e(route('createPostStep3', ['id' => $post->id])); ?>'" value="ذخیره" class="btn btn-success">
            </center>

        </div>
    </div>

    <div class="col-md-1"></div>

    <script>

        var whichTag;

        function handleClick(id, placeId, mode) {
            whichTag = mode;
        }

        function handleSubmitFormDataTable() {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('editPostTag')); ?>',
                data: {
                    'id': '<?php echo e($post->id); ?>',
                    'whichTag': whichTag,
                    'val': $(".myDynamicInput").val()
                }
            });
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/post/createPostStep2.blade.php ENDPATH**/ ?>