<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .col-xs-12 {
            margin: 5px;
        }

        button {
            min-width: 200px;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>آخرین مطالب کاربران</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">
                <center class="row">
                    <div class="col-xs-12">
                        <h3>فعالیت های موجود</h3>
                    </div>
                    <?php if(count($activities) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">فعالیتی وجود ندارد</h4>
                        </div>
                    <?php else: ?>
                        <?php $__currentLoopData = $activities; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $activity): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-xs-12">
                                <button onclick="document.location.href = '<?php echo e(route('controlActivityContent', ['activityId' => $activity->id])); ?>'" class="btn btn-primary" data-toggle="tooltip" title="" style="width: auto">
                                    <?php echo e($activity->name); ?>

                                </button>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-xs-12">
                            <button onclick="document.location.href = '<?php echo e(route('controlActivityContent', ['activityId' => 'post'])); ?>'" class="btn btn-primary" data-toggle="tooltip" title="" style="width: auto">
                                دیدگاه های پست ها
                            </button>
                        </div>
                    <?php endif; ?>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/user/controlContent.blade.php ENDPATH**/ ?>