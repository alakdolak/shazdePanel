<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        td {
            padding: 7px;
            border: 2px solid;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8" style="direction: rtl">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>بک آپ ها</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">

                    <?php if(count($backups) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">بک آپی وجود ندارد</h4>
                        </div>
                    <?php else: ?>

                        <table>
                            <tr>
                                <td><center>نوع بک آپ</center></td>
                                <td><center>url داده شده</center></td>
                                <td><center>نام کاربری</center></td>
                                <td><center>رمز عبور</center></td>
                                <td><center>دوره دریافت</center></td>
                                <td><center>عملیات</center></td>
                            </tr>
                            <?php $__currentLoopData = $backups; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr id="row_<?php echo e($itr->id); ?>">
                                    <td><center><?php echo e($itr->kind); ?></center></td>
                                    <td><center><?php echo e($itr->url); ?></center></td>
                                    <td><center><?php echo e($itr->username); ?></center></td>
                                    <td><center><?php echo e($itr->password); ?></center></td>
                                    <td><center><?php echo e($itr->interval); ?></center></td>
                                    <td><center><span style="cursor: pointer" onclick="deleteBackup('<?php echo e($itr->id); ?>')" class="glyphicon glyphicon-trash"></span></center></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </table>

                    <?php endif; ?>

                    <div class="col-xs-12">
                        <button id="addBtn" onclick="addBackup()" class="btn btn-default transparentBtn" style="width: auto" data-toggle="modal" data-target="#InformationproModalalert">
                            <span class="glyphicon glyphicon-plus"></span>
                        </button>
                    </div>

                    <a target="_blank" href="<?php echo e(route('manualBackup')); ?>" style="color: white; margin: 20px" class="btn btn-danger">دریافت بک آپ دستی از دیتابیس</a>
                    <span onclick="getBackUp()" style="color: white; margin: 20px" class="btn btn-danger">دریافت بک آپ دستی از تصاویر</span>

                    <div id="percentDiv" class="hidden">
                        <p>در حال ایجاد بک آپ</p>
                        <p id="percent"></p>
                        <div style="margin-top: 20px; text-align: center" id="links">
                            <p>لینک های دانلود</p>
                        </div>
                    </div>

                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>

    <script>

        var percent = 0;
        var timer;

        function deleteBackup(id) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('removeBackup')); ?>',
                data: {
                    'id': id
                }
            });

            $("#row_" + id).remove();
        }

        function getBackUp() {

            $("#percentDiv").removeClass('hidden');
            $("#percent").empty().append(percent + "%");

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('initialImageBackUp')); ?>',
                success: function () {

                    timer = setTimeout(getDonePercentage, 5000);

                    $.ajax({
                        type: 'post',
                        url: '<?php echo e(route('imageBackup')); ?>'
                    });
                }
            });
        }

        var counter = 1;

        function getDonePercentage() {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('getDonePercentage')); ?>',
                success: function (response) {

                    response = JSON.parse(response);
                    percent = parseFloat(response.percent);
                    if(Number.isNaN(percent))
                        return;
                    $("#percent").empty().append(percent + "%");
                    var url = response.url;

                    if(url != "") {
                        $("#links").append('<a style="display: block" href="' + response.url + '" download>لینک ' + (counter++) + '</a>');
                    }
                    if(percent != 100)
                        timer = setTimeout(getDonePercentage, 5000);
                }
            });
        }
        
        function addBackup() {
            createModal('<?php echo e(route('addBackup')); ?>',
                    [
                        {'name': 'url', 'class': [], 'type': 'text', 'label': 'آدرس مقصد', 'value': ''},
                        {'name': 'username', 'class': [], 'type': 'text', 'label': 'نام کاربری', 'value': ''},
                        {'name': 'password', 'class': [], 'type': 'password', 'label': 'رمزعبور', 'value': ''},
                        {'name': 'interval', 'value': '', 'class': [], 'type': 'select', 'label': 'وضعیت جدید', 'options': '<?php echo json_encode($intervals); ?>'}
                    ],
                    'افزودن بک آپ جدید', '<?php echo e((isset($msg) ? $msg : '')); ?>'
            );
        }

    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/backup.blade.php ENDPATH**/ ?>