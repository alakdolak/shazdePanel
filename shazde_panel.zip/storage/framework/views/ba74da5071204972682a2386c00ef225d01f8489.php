<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت شرکت های تبلیغاتی</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">

                    <?php if(count($company) == 0): ?>
                        <div class="col-xs-12">
                            <h4 class="warning_color">شرکتی وجود ندارد</h4>
                        </div>
                    <?php else: ?>
                        <form method="post" action="<?php echo e(route('deleteCompany')); ?>">
                            <?php echo e(csrf_field()); ?>

                            <?php $__currentLoopData = $company; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-xs-12">
                                    <span>
                                        <?php echo e($itr->name); ?>

                                    </span>

                                    <button name="deleteCompany" value="<?php echo e($itr->id); ?>" class="sparkline9-collapse-close transparentBtn" data-toggle="tooltip" title="حذف سطح" style="width: auto">
                                        <span ><i class="fa fa-times"></i></span>
                                    </button>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </form>
                    <?php endif; ?>

                    <div class="col-xs-12">
                        <button id="addBtn" onclick="createModal('<?php echo e(route('company')); ?>', [{'name': 'name', 'class': [], 'type': 'text', 'label': 'نام شرکت', 'value': ''}], 'افزودن شرکت جدید', '<?php echo e((isset($msg) ? $msg : '')); ?>')" class="btn btn-default transparentBtn" style="width: auto" data-toggle="modal" data-target="#InformationproModalalert">
                            <span class="glyphicon glyphicon-plus"></span>
                        </button>
                    </div>

                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/publicity/company.blade.php ENDPATH**/ ?>