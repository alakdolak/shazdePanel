<?php $__env->startSection('header'); ?>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/switch.css')); ?>">
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        .myLabel {
            padding: 10px;
            min-width: 200px;
            display: inline-block;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>


    <div class="col-md-2"></div>

    <div class="col-md-8">
        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت دسترسی</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('seo')" type="checkbox" <?php echo e(($access->seo) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت سئو ها</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('alt')" type="checkbox" <?php echo e(($access->alt) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span style="direction: rtl" class="myLabel">مدیریت alt ها و تصاویر</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('content')" type="checkbox" <?php echo e(($access->content) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت محتوای صفحات</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('post')" type="checkbox" <?php echo e(($access->post) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت پست ها</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('comment')" type="checkbox" <?php echo e(($access->comment) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت کامنت ها</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('config')" type="checkbox" <?php echo e(($access->config) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت تنظیمات سیستمی</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('offCode')" type="checkbox" <?php echo e(($access->offCode) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت کد های تخفیف</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('publicity')" type="checkbox" <?php echo e(($access->publicity) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت تبلیغات</span>
                    </div>

                    <div class="col-xs-12">
                        <label class="switch">
                            <input onchange="changeAccess('msg')" type="checkbox" <?php echo e(($access->msg) ? 'checked' : ''); ?>>
                            <span class="slider round"></span>
                        </label>
                        <span class="myLabel">مدیریت پیام رسانی</span>
                    </div>

                </center>
            </div>

        </div>
    </div>

    <div class="col-md-2"></div>
    
    <script>
        
        function changeAccess(val) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('changeAccess')); ?>',
                data: {
                    'userId': '<?php echo e($userId); ?>',
                    'val': val
                }
            });

        }
        
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/users/manageAccess.blade.php ENDPATH**/ ?>