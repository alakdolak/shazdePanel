<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/form.css')); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <form method="post" action="<?php echo e(route('doLogin')); ?>">

        <?php echo e(csrf_field()); ?>


        <div class="login-form-area mg-t-30 mg-b-40">
        <div class="container-fluid">
            <div class="row" style="direction: rtl">
                <div class="col-lg-4"></div>
                <div class="col-lg-4">
                    <div class="login-bg">
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="logo">
                                    <a href="#"><img src="<?php echo e(URL::asset('img/logo.png')); ?>" alt="" />
                                    </a>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-12">
                                <div class="login-title">
                                    <h1>فرم ورود</h1>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="login-input-area">
                                    <input type="text" name="username" />
                                    <i class="fa fa-user login-user" aria-hidden="true"></i>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="login-input-head">
                                    <p>نام کاربری</p>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-lg-8">
                                <div class="login-input-area">
                                    <input type="password" name="password" />
                                    <i class="fa fa-lock login-user"></i>
                                </div>
                            </div>
                            <div class="col-lg-4">
                                <div class="login-input-head">
                                    <p>رمزعبور</p>
                                </div>
                            </div>
                        </div>
                        <center class="row">
                            <div class="login-button-pro">
                                <button type="submit" class="login-button login-button-lg">ورود</button>
                                <p style="margin-top: 10px"><?php echo e($msg); ?></p>
                            </div>
                        </center>
                    </div>
                </div>
                <div class="col-lg-4"></div>
            </div>
        </div>
    </div>

    </form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/login.blade.php ENDPATH**/ ?>