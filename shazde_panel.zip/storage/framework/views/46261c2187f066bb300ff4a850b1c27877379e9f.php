<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <style>

        table {
            direction: rtl;
        }

        th {
            text-align: right !important;
        }

        .fixed-table-body {
            overflow-y: hidden;
        }

        .fixed-table-pagination {
            margin-top: 15px;
        }

    </style>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="static-table-area mg-b-15">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-12">
                    <div class="sparkline9-list sparkel-pro-mg-t-30 shadow-reset">
                        <div class="sparkline9-hd">
                            <div style="direction: rtl" class="main-sparkline9-hd">
                                <h1>کاربران</h1>
                            </div>
                        </div>
                        <div class="sparkline13-graph">
                            <div class="datatable-dashv1-list custom-datatable-overright">
                                <table id="table" data-toggle="table" data-pagination="true" data-search="true" data-show-columns="true" data-show-pagination-switch="true" data-show-refresh="true" data-key-events="true" data-show-toggle="true" data-resizable="true" data-cookie="true" data-cookie-id-table="saveId" data-show-export="true" data-click-to-select="true" data-toolbar="#toolbar">
                                    <thead>
                                        <tr>
                                            <th>آی دی</th>
                                            <th>نام و نام خانوادگی</th>
                                            <th>نام کاربری</th>
                                            <th>ایمیل</th>
                                            <th>شماره همراه</th>
                                            <th>شهر</th>
                                            <th>استان</th>
                                            <th>تصویر</th>
                                            <th>سطح دسترسی</th>
                                            <th>وضعیت اکانت</th>
                                            <th>عملیات</th>
                                        </tr>
                                        </thead>
                                    <tbody>

                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                            <tr>
                                                <td><?php echo e($user->id); ?></td>
                                                <td><?php echo e($user->first_name . ' ' . $user->last_name); ?></td>
                                                <td><?php echo e($user->username); ?></td>
                                                <td><?php echo e($user->email); ?></td>
                                                <td><?php echo e($user->phone); ?></td>
                                                <td><?php echo e($user->cityName); ?></td>
                                                <td><?php echo e($user->stateName); ?></td>
                                                <td><img width="50px" src="<?php echo e($user->pic); ?>"></td>
                                                <td><?php echo e($user->level); ?></td>
                                                <td id="status_<?php echo e($user->id); ?>" data-status="<?php echo e(($user->status == 'فعال') ? 1 : 0); ?>"><?php echo e($user->status); ?></td>
                                                <td>
                                                    <?php if($user->level == 'کاربر عادی'): ?>
                                                        <a href="<?php echo e(route('manageAccess', ['userId' => $user->id])); ?>" class="btn btn-default">فعالیت ها</a>
                                                    <?php elseif($user->level == 'ادمین'): ?>
                                                        <a href="<?php echo e(route('manageAccess', ['userId' => $user->id])); ?>" class="btn btn-default">مدیریت سطح دسترسی</a>
                                                    <?php endif; ?>

                                                    <?php if($user->level != 'ادمین کل'): ?>
                                                        <button class="btn btn-danger" onclick="toggleStatus('<?php echo e($user->id); ?>')">تغییر وضعیت اکانت</button>
                                                    <?php endif; ?>

                                                    <button onclick="createAjaxModal('<?php echo e(route('changePass')); ?>', [{'name': 'password', 'class': [], 'type': 'password', 'label': 'رمز جدید', 'value': ''}, {'name': 'confirmPass', 'class': [], 'type': 'password', 'label': 'تکرار رمزعبور جدید', 'value': ''}, {'name': 'userId', 'class': ['hidden'], 'type': 'hidden', 'label': '', 'value': '<?php echo e($user->id); ?>'}], 'تغییر رمزعبور', '')" style="display: block; margin: 7px" class="btn btn-warning" data-toggle="modal" data-target="#InformationproModalalertAjax">تغییر رمزعبور</button>
                                                </td>
                                            </tr>

                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <script>

        function toggleStatus(userId) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('toggleStatusUser')); ?>',
                data: {
                    'userId': userId
                }
            });

            var elem = $("#status_" + userId);

            var currStatus = parseInt(elem.attr('data-status'));

            if(currStatus == 1) {
                elem.attr('data-status', 0).html('غیر فعال');
            }
            else {
                elem.attr('data-status', 1).html('فعال');
            }

        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/users/users.blade.php ENDPATH**/ ?>