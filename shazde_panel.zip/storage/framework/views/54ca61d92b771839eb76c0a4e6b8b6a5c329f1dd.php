<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }

        .rtl {
            direction: rtl;
        }
        .sparkline-outline-iconRTL {
            left: 0;
            right: auto;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <?php $i = 0; ?>

    <button id="addBtn" class="hidden btn btn-default transparentBtn" style="width: auto" data-toggle="modal" data-target="#InformationproModalalert"></button>

    <?php $__currentLoopData = $photos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $j = 0; ?>
        <div class="col-lg-6">
            <div class="sparkline<?php echo e(($i + 8)); ?>-list ct-map-b-mg-30 shadow-reset">
                <div class="sparkline<?php echo e(($i + 8)); ?>-hd">
                    <div class="rtl main-sparkline<?php echo e(($i + 8)); ?>-hd">
                        <h1>
                            <span>تگ alt</span>
                            <span>:</span>
                            <span>&nbsp;</span>
                            <span><?php echo e($alts[$i]); ?></span>
                        </h1>
                        <div class="sparkline-outline-iconRTL sparkline<?php echo e(($i + 8)); ?>-outline-icon">
                            <span class="sparkline<?php echo e(($i + 8)); ?>-collapse-link"><i class="fa fa-chevron-up"></i></span>
                            <span onclick="localCreateModal('<?php echo e($alts[$i]); ?>', '<?php echo e($i); ?>')"><i class="fa fa-wrench"></i></span>
                            <?php if($i != 0): ?>
                                <span onclick="removeMainPic('<?php echo e($i); ?>')" class="sparkline<?php echo e(($i + 8)); ?>-collapse-close"><i class="fa fa-times"></i></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="sparkline<?php echo e(($i + 8)); ?>-graph">
                    <div class="data-map-single">
                        <div>
                            <?php $__currentLoopData = $photo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itr): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <p style="margin-top: 10px; direction: rtl"><?php echo e($metaPhoto[$i][$j]); ?></p>
                                <span style="cursor: pointer" onclick="localCreateModalForPic('<?php echo e($i); ?>', '<?php echo e($j); ?>')"><i class="fa fa-wrench"></i></span>
                                <img src="<?php echo e($itr); ?>">
                                <?php $j++ ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <?php $i++; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <?php $__currentLoopData = $userPhotos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $photo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <?php $j = 0; ?>
        <div class="col-lg-6">
            <div class="sparkline<?php echo e(($i + 8)); ?>-list ct-map-b-mg-30 shadow-reset">
                <div class="sparkline<?php echo e(($i + 8)); ?>-hd">
                    <div class="rtl main-sparkline<?php echo e(($i + 8)); ?>-hd">
                        <h1>
                            <span>تگ alt</span>
                            <span>:</span>
                            <span>&nbsp;</span>
                            <span><?php echo e($photo->alt); ?></span>
                        </h1>
                        <div class="sparkline-outline-iconRTL sparkline<?php echo e(($i + 8)); ?>-outline-icon">
                            <span class="sparkline<?php echo e(($i + 8)); ?>-collapse-link"><i class="fa fa-chevron-up"></i></span>
                            <span onclick="localCreateModalForUserPic('<?php echo e($photo->alt); ?>', '<?php echo e($photo->subject); ?>', '<?php echo e($photo->category); ?>', '<?php echo e($photo->id); ?>', '<?php echo e($photo->confirm); ?>')"><i class="fa fa-wrench"></i></span>
                            <?php if($i != 0): ?>
                                <span onclick="removeUserPic('<?php echo e($photo->id); ?>')" class="sparkline<?php echo e(($i + 8)); ?>-collapse-close"><i class="fa fa-times"></i></span>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
                <div class="sparkline<?php echo e(($i + 8)); ?>-graph">
                    <div class="data-map-single">
                        <p style="direction: rtl"><span>توضیحات:</span><span>&nbsp;</span><span><?php echo e($photo->subject); ?></span></p>
                        <p style="direction: rtl"><span>دسته:</span><span>&nbsp;</span><span><?php echo e($photo->category); ?></span></p>
                        <p style="direction: rtl"><span>وضعیت:</span><span>&nbsp;</span><span><?php echo e($photo->confirm); ?></span></p>
                        <?php $j = 0; ?>
                        <?php $__currentLoopData = $photo->pics; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pic): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div>
                                <span style="cursor: pointer" onclick="localCreateModalForChangeUserPic('<?php echo e($photo->id); ?>', '<?php echo e($j); ?>')"><i class="fa fa-wrench"></i></span>
                                <img src="<?php echo e($pic); ?>">
                            </div>
                            <?php $j++; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                </div>
            </div>
        </div>
        <?php $i++; ?>

    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

    <script>

        function removeUserPic(id) {
            $.ajax({
                type: 'post',
                url: '<?php echo e(route('removeUserPic')); ?>',
                data: {
                    'id': id
                }
            });
        }
        
        function removeMainPic(idx) {

            $.ajax({
                type: 'post',
                url: '<?php echo e(route('removeMainPic', ['id' => $id, 'kindPlaceId' => $kindPlaceId])); ?>',
                data: {
                    'idx': idx
                }
            });
        }
        
        function localCreateModal(currAlt, idx) {
            createModal(
                '<?php echo e(route('doChangeAlt', ['id' => $id, 'kindPlaceId' => $kindPlaceId])); ?>',
                [
                    {'name': 'alt', 'value': currAlt, 'class': [], 'type': 'text', 'label': 'تگ جدید'},
                    {'name': 'idx', 'value': idx, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'}
                ],
                'تغییر تگ alt',
                ''
            );

            setTimeout(function(){
                $("#addBtn").click();
            }, 1);
        }

        function localCreateModalForUserPic(currAlt, currSubject, currCategory, id, currConfirm) {
            createModal(
                    '<?php echo e(route('doChangeAltForUserPic')); ?>',
                    [
                        {'name': 'alt', 'value': currAlt, 'class': [], 'type': 'text', 'label': 'تگ جدید'},
                        {'name': 'id', 'value': id, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'},
                        {'name': 'subject', 'value': currSubject, 'class': [], 'type': 'text', 'label': 'توضیحات جدید'},
                        {'name': 'category', 'value': currCategory, 'class': [], 'type': 'select', 'label': 'دسته جدید', 'options': '<?php echo json_encode($picItems); ?>'},
                        {'name': 'confirm', 'value': currConfirm, 'class': [], 'type': 'select', 'label': 'وضعیت جدید', 'options': '<?php echo json_encode($acceptance); ?>'}
                    ],
                    'تغییر تگ alt',
                    ''
            );

            setTimeout(function(){
                $("#addBtn").click();
            }, 1);
        }

        function localCreateModalForPic(idx, sizeIdx) {
            createModal(
                    '<?php echo e(route('doChangePic', ['id' => $id, 'kindPlaceId' => $kindPlaceId])); ?>',
                    [
                        {'name': 'pic', 'value': '', 'class': [], 'type': 'file', 'label': 'فایل جدید'},
                        {'name': 'idx', 'value': idx, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'},
                        {'name': 'sizeIdx', 'value': sizeIdx, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'}
                    ],
                    'تغییر تصویر',
                    '',
                    true
            );

            setTimeout(function(){
                $("#addBtn").click();
            }, 1);
        }

        function localCreateModalForChangeUserPic(id, idx) {

            createModal(
                    '<?php echo e(route('doChangeUserPic')); ?>',
                    [
                        {'name': 'pic', 'value': '', 'class': [], 'type': 'file', 'label': 'فایل جدید'},
                        {'name': 'id', 'value': id, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'},
                        {'name': 'idx', 'value': idx, 'class': ['hidden'], 'type': 'text', 'label': 'تگ جدید'}
                    ],
                    'تغییر تصویر',
                    '',
                    true
            );

            setTimeout(function(){
                $("#addBtn").click();
            }, 1);
        }

    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/content/changeAlt.blade.php ENDPATH**/ ?>