<?php $__env->startSection('header'); ?>
    ##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##

    <script src = <?php echo e(URL::asset("js/calendar.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/calendar-setup.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/calendar-fa.js")); ?>></script>
    <script src = <?php echo e(URL::asset("js/jalali.js")); ?>></script>
    <link rel="stylesheet" href="<?php echo e(URL::asset('css/standalone.css')); ?>">
    <link rel="stylesheet" href = <?php echo e(URL::asset("css/calendar-green.css")); ?>>

    <style>
        .col-xs-12 {
            margin-top: 10px;
        }

        button {
            margin-right: 10px;
        }

        .row {
            direction: rtl;
        }

        .calendar2 {
            top: 113% !important;
            left: 27% !important;
        }
    </style>

    <style>
        .calendar2 {
            top: 113% !important;
            left: 27% !important;
        }
    </style>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php echo $__env->make('layouts.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div class="col-md-2"></div>

    <div class="col-md-8">

        <div class="sparkline8-list shadow-reset mg-tb-30">
            <div class="sparkline8-hd">
                <div class="main-sparkline8-hd">
                    <h1>مدیریت تبلیغات</h1>
                </div>
            </div>

            <div class="sparkline8-graph dashone-comment messages-scrollbar dashtwo-messages">

                <center class="row">
                    <div class="col-xs-12">
                        <h3>تبلیغات</h3>
                    </div>

                    <?php if($mode == "see"): ?>

                        <?php if(count($ads) == 0): ?>
                            <div class="col-xs-12">
                                <h4 class="warning_color">تبلیغی وجود ندارد</h4>
                            </div>
                        <?php else: ?>
                            <form method="post" action="<?php echo e(route('deleteAd')); ?>">
                                <?php echo e(csrf_field()); ?>

                                <?php $__currentLoopData = $ads; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ad): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xs-12">
                                        <img width="100" height="100" src="<?php echo e(URL::asset('ads') . '/' . $ad->pic); ?>">
                                        <span>نام شرکت </span><span><?php echo e($ad->companyId); ?></span>
                                        <span>محل قرارگیری </span> <span><?php echo e($ad->sections); ?></span>
                                        <span> از <?php echo e($ad->from_); ?> تا <?php echo e($ad->to_); ?></span>
                                        <span> استان ها </span> <span><?php echo e($ad->states); ?></span>

                                        <a href="<?php echo e(route('editAd', ['adId' => $ad->id])); ?>" name="editLevel" class="sparkline9-collapse-link transparentBtn" data-toggle="tooltip" title="ویرایش تبلیغ" style="width: auto">
                                            <span class="fa fa-wrench"></span>
                                        </a>
                                        <button name="adId" value="<?php echo e($ad->id); ?>" class="sparkline9-collapse-close transparentBtn" data-toggle="tooltip" title="حذف تبلیغ" style="width: auto">
                                            <span ><i class="fa fa-times"></i></span>
                                        </button>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </form>
                        <?php endif; ?>

                        <div class="col-xs-12">
                            <a href="<?php echo e(route('addAds')); ?>">
                                <button class="btn btn btn-default" style="width: auto; border-radius: 50% 50% 50% 50%" data-toggle="tooltip" title="اضافه کردن تبلیغ جدید">
                                    <span class="glyphicon glyphicon-plus" style="margin-left: 30%"></span>
                                </button>
                            </a>
                        </div>
                    <?php elseif($mode == "add"): ?>
                        <form method="post" action="<?php echo e(route('addAds')); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-xs-12">
                                <label>
                                    <span>نام شرکت</span>
                                    <select name="companyId">
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>استان های مورد نظر</span>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <label for="state_<?php echo e($state->id); ?>"><?php echo e($state->name); ?></label>
                                            <input id="state_<?php echo e($state->id); ?>" type="checkbox" value="<?php echo e($state->id); ?>" name="states[]">
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>صفحات مورد نظر</span>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <label for="section_<?php echo e($section->id); ?>"><?php echo e($section->name); ?></label>
                                            <input id="section_<?php echo e($section->id); ?>" type="checkbox" value="<?php echo e($section->id); ?>" name="sections[]">
                                            <span id="part_<?php echo e($section->id); ?>"></span>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>url</span>
                                    <input type="text" name="url" required maxlength="300">
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>تصویر</span>
                                    <input type="file" name="pic" accept="image/png" required>
                                </label>
                            </div>

                            <div class="col-xs-12">

                                <center class="col-xs-6">
                                    <input type="button"
                                           style="border: none; width: 15px;  height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                           id="date_btn_end">
                                    <span>تا تاریخ</span>

                                    <input type="text" style="max-width: 200px" class="form-detail"
                                           name="endDate" id="date_input_end" onchange="end()" readonly>

                                    <script>
                                        Calendar.setup({
                                            inputField: "date_input_end",
                                            button: "date_btn_end",
                                            ifFormat: "%Y/%m/%d",
                                            dateType: "jalali"
                                        });
                                    </script>
                                </center>

                                <center class="col-xs-6">

                                    <input type="button"
                                           style="border: none;  width: 15px; height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                           id="date_btn_Start">

                                    <span style="direction: rtl">از تاریخ</span>

                                    <input type="text" style="max-width: 200px" class="form-detail"
                                           name="startDate" id="date_input_start" onchange="start()" readonly>

                                    <script>
                                        Calendar.setup({
                                            inputField: "date_input_start",
                                            button: "date_btn_Start",
                                            ifFormat: "%Y/%m/%d",
                                            dateType: "jalali"
                                        });
                                    </script>
                                </center>

                            </div>

                            <div class="col-xs-12">
                                <p class="warning_color"><?php echo e($msg); ?></p>
                                <input type="submit" name="addPublicity" value="اضافه کن" class="btn btn-primary" style="width: auto; margin-top: 10px">
                            </div>
                        </form>
                    <?php else: ?>
                        <form method="post" action="<?php echo e(route('editAd', ['adId' => $ad->id])); ?>" enctype="multipart/form-data">
                            <?php echo e(csrf_field()); ?>

                            <div class="col-xs-12">
                                <label>
                                    <span>نام شرکت</span>
                                    <select name="companyId">
                                        <?php $__currentLoopData = $companies; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $company): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <?php if($ad->companyId == $company->id): ?>
                                                <option selected value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                            <?php else: ?>
                                                <option value="<?php echo e($company->id); ?>"><?php echo e($company->name); ?></option>
                                            <?php endif; ?>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>استان های مورد نظر</span>
                                    <?php $__currentLoopData = $states; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $state): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <label for="state_<?php echo e($state->id); ?>"><?php echo e($state->name); ?></label>
                                            <?php if($state->select == 1): ?>
                                                <input checked id="state_<?php echo e($state->id); ?>" type="checkbox" value="<?php echo e($state->id); ?>" name="states[]">
                                            <?php else: ?>
                                                <input id="state_<?php echo e($state->id); ?>" type="checkbox" value="<?php echo e($state->id); ?>" name="states[]">
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>صفحات مورد نظر</span>
                                    <?php $__currentLoopData = $sections; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $section): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div>
                                            <label for="section_<?php echo e($section->id); ?>"><?php echo e($section->name); ?></label>
                                            <?php if($section->select == 1): ?>
                                                <input checked id="section_<?php echo e($section->id); ?>" type="checkbox" value="<?php echo e($section->id); ?>" name="sections[]">
                                            <?php else: ?>
                                                <input id="section_<?php echo e($section->id); ?>" type="checkbox" value="<?php echo e($section->id); ?>" name="sections[]">
                                            <?php endif; ?>
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </label>
                            </div>
                            <div class="col-xs-12">
                                <label>
                                    <span>url</span>
                                    <input type="text" value="<?php echo e($ad->url); ?>" name="url" required maxlength="300">
                                </label>
                            </div>

                            <script>
                                $(document).ready(function() {
                                    writeFileName('<?php echo e($ad->pic); ?>');
                                });

                                function writeFileName(val) {
                                    $("#fileName").empty().append(val);
                                }
                            </script>

                            <div class="col-xs-12">
                                <label>
                                    <input onchange="writeFileName(this.value)" id="photo" type="file" name="pic">
                                    <label for="photo">
                                        <div class="ui_button primary addPhotoBtn">تصویر </div>
                                    </label>
                                    <p id="fileName"></p>
                                </label>
                            </div>

                            <div class="col-xs-12">

                                <center class="col-xs-6">
                                    <input type="button"
                                           style="border: none; width: 15px;  height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                           id="date_btn_end">
                                    <span>تا تاریخ</span>

                                    <input type="text" style="max-width: 200px" class="form-detail"
                                           name="endDate" value="<?php echo e(convertStringToDate($ad->to_)); ?>" id="date_input_end" onchange="end()" readonly>

                                    <script>
                                        Calendar.setup({
                                            inputField: "date_input_end",
                                            button: "date_btn_end",
                                            ifFormat: "%Y/%m/%d",
                                            dateType: "jalali"
                                        });
                                    </script>
                                </center>

                                <center class="col-xs-6">

                                    <input type="button"
                                           style="border: none;  width: 15px; height: 15px; background: url(<?php echo e(URL::asset('img/calender.png')); ?>) repeat 0 0; background-size: 100% 100%;"
                                           id="date_btn_Start">

                                    <span style="direction: rtl">از تاریخ</span>

                                    <input type="text" style="max-width: 200px" class="form-detail"
                                           name="startDate" value="<?php echo e(convertStringToDate($ad->from_)); ?>" id="date_input_start" onchange="start()" readonly>

                                    <script>
                                        Calendar.setup({
                                            inputField: "date_input_start",
                                            button: "date_btn_Start",
                                            ifFormat: "%Y/%m/%d",
                                            dateType: "jalali"
                                        });
                                    </script>
                                </center>

                            </div>

                            <div class="col-xs-12">
                                <p class="warning_color"><?php echo e($msg); ?></p>
                                <input type="submit" name="addPublicity" value="ویرایش" class="btn btn-primary" style="width: auto; margin-top: 10px">
                            </div>
                        </form>
                    <?php endif; ?>
                </center>
            </div>
        </div>
    </div>

    <div class="col-md-2"></div>

    <script>

        function editDateTrip() {

            $("#date_input_start_edit_2").datepicker({
                numberOfMonths: 2,
                showButtonPanel: true,
                minDate: 0,
                dateFormat: "yy/mm/dd"
            });
        }
        function editDateTripEnd() {

            $("#date_input_end_edit_2").datepicker({
                numberOfMonths: 2,
                showButtonPanel: true,
                minDate: 0,
                dateFormat: "yy/mm/dd"
            });
        }
    </script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.structure', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\shazde_panel\resources\views/config/publicity/ads.blade.php ENDPATH**/ ?>